echo $0
echo $1  $2   $3
echo "all variables $*"
echo "number of argument: $#"

echo "enter number"
read num1
echo "enter number"
read num2
a=`expr $num1 + $num2`
echo $a
m=`expr $num1 \* $num2`
echo $m
d=`expr $num1 / $num2`
echo $d

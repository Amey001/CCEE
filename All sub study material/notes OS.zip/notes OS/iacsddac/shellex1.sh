mkdir $1
cp $2 $3

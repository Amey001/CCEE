echo "enter number"
read num1
echo "enter num"
read num2
let ans=num1+num2
let mul=num1*num2
echo "addition : $ans"
echo "multiplication :$mul"
let num1++
echo $num1
